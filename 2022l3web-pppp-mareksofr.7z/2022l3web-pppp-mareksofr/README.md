﻿# První projekt pro praxi

[Figma](https://www.figma.com/file/eO2Z56bQyEG95vkSYuwGYs/L3---4P-projekt-(Copy)?node-id=0%3A1&t=jS5GyE29iqWwjp81-0)


[Můj web](https://pslib-cz.github.io/2022l3web-pppp-mareksofr/)
